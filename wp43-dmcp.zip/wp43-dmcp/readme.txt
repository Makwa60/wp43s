To change the firmware on a DM42, use the following instructions.
*Warning:* this is a very early version of the WP43 program for DM42
so use it at your own risk.

## Updating the DMCP Firmware

The WP43 firmware requires a recent version of the DMCP firmware. If
you have never updated this for your calculator (or have not updated
this recently) then this should be updated first.

1. Start your computer. Take a DM42 and turn it on; then
   - if you are using DM42 firmware:
     press [Setup] [5] (System) [2] (Enter system menu)
     [4] (Reset to DMCP menu)
   - if you are using a previous version of WP43 firmware:
     press [gMODE] [gSYSTEM]
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the plastic edge a bit may be
     necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Start the internet browser on your computer and go to 
   [the SwissMicros firmware website](https://technical.swissmicros.com/dm42/firmware/).
   - Download the most recent file within the `DMCP` directory and
     copy this to the DM42 flash disk.
3. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
4. The DMCP firmware will automatically detect the update. Press
   [ENTER] to continue upgrading the DMCP.
5. After a few seconds the firmware will be complete. Press [EXIT]
   to continue.

## Convert a DM42 to a WP43

1. Start your computer. Take a DM42 and turn it on; then
   - press [Setup] [5] (System) [2] (Enter system menu)
     [4] (Reset to DMCP menu)
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the plastic edge a bit may be
     necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Download the
   [latest release](https://gitlab.com/wpcalculators/wp43/-/releases)
   of WP43 for DM42.
   - Copy the files `WP43.pgm` and `WP43_qspi.bin` to the DM42
     flash disk.
   - Option: Copying `testPgms.bin` to the DM42 flash disk will give
     you some test programs pre-entered.
   - Option: Also copying `keymap.bin` to the DM42 flash disk will
     reassign keys to match the WP43 layout (for all functionality of
     the device). Unless you have done this, [EXIT] stays bottom left,
     which is the only effect.
   - Delete any other files ending `_qspi.bin` or `.pgm` because the
     calculator may attempt to load those instead of the WP43 firmware.
3. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
4. Press [4] (Load QSPI from FAT). This will automatically detect the
   relevant file and flash it to the DM42. It should be completed in
   seconds.
   - Press any key to restart followed by [EXIT] [3] (DMCP Menu).
5. Press [3] (Load Program) and select `WP43.pgm`. Wait about 15s for
   flashing to complete. Then press [EXIT] [EXIT] [1]. Then press the
   key in the bottom left (either [+] or [EXIT]). Now, your WP43 is
   up and waiting for your commands.

See [the Wiki](https://gitlab.com/wpcalculators/wp43/-/wikis/DM42-conversion)
for further details on how to produce a custom overlay and stickers to
make it easier to use your WP43 calculator.

## Update WP43 to the latest version

1. Start your computer. Take a DM42 and turn it on; then
   - press [gMODE] [gSYSTEM]
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the plastic edge a bit may be
     necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Download the
   [latest release](https://gitlab.com/wpcalculators/wp43/-/releases)
   of WP43 for DM42.
   - Copy the files `WP43.pgm` and `WP43_qspi.bin` to the DM42
     flash disk.
   - Option: Copying `testPgms.bin` to the DM42 flash disk will give
     you some test programs pre-entered.
   - Option: Also copying `keymap.bin` to the DM42 flash disk will
     reassign keys to match the WP43 layout (for all functionality of
     the device). This should be done whenever the keymap file changes.
     The last such change was in March 2020.
   - Delete any other files ending `_qspi.bin` or `.pgm` because the
     calculator may attempt to load those instead of the WP43 firmware.
3. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
4. Press [4] (Load QSPI from FAT). This will automatically detect the
   relevant file and flash it to the DM42. It should be completed in
   seconds.
   - Press any key to restart followed by [EXIT] [3] (DMCP Menu).
5. Press [3] (Load Program) and select `WP43.pgm`. Wait about 15s for
   flashing to complete. Then press [EXIT] [EXIT] [1]. Then press the
   key in the bottom left (either [+] or [EXIT]). Now, your WP43 is
   up and waiting for your commands.

## Converting a WP43 back to a DM42

1. Start your computer. Take a DM42 and turn it on; then
   - press [gMODE] [gSYSTEM]
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the plastic edge a bit may be
     necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Start the internet browser on your computer and go to 
   [the SwissMicros firmware website](https://technical.swissmicros.com/dm42/firmware/).
   - Download the most recent file beginning `DM42` and ending `.pgm`
     in that directory.
   - Download the most recent file in the `qspi_data` subdirectory
     beginning `DM42_qspi` and ending `.bin`.
   - Copy these both to the DM42 flash disk.
   - Delete any other files ending `_qspi.bin` or `.pgm` because the
     calculator may attempt to load those instead of the DM42 firmware.
3. If you updated the keymap file when flashing the WP43 firmware
   then restore the keymap by copying the `original_DM42_keymap.bin`
   file in the [latest WP43 release](https://gitlab.com/wpcalculators/wp43/-/releases)
   to the DM42 flash disk.
4. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
5. Press [4] (Load QSPI from FAT). This will automatically detect the
   relevant file and flash it to the DM42. It should be completed in
   seconds.
   - Press any key to restart followed by [EXIT] [3] (DMCP Menu).
6. Press [3] (Load Program) and select the `DM42` file ending in `pgm`.
   Wait about 15s for flashing to complete. Then press
   [EXIT] [EXIT]. Now, your DM42 has been restored and is waiting for
   your commands.